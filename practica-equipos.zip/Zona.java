package practicaequipos;

public class Zona {
	 int idZona;
	 String nombre;
}
