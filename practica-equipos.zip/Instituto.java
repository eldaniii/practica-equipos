package practicaequipos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Instituto {
	private Map<String, HashMap<Integer, LinkedHashSet<String>>> profHistoricoZona;
	private Map<Integer, LinkedHashSet<String>> mapaDiaProfW;
	
	
	
	public Instituto() {
		this.profHistoricoZona = new HashMap<String, HashMap<Integer, LinkedHashSet<String>>>();
	}
	public void cargaHistorico() {
		try {
				
				Map<String,HashMap<Integer, LinkedHashSet<String>>>  prov = new HashMap<String,HashMap<Integer, LinkedHashSet<String>>>();
				
				BufferedReader in = new BufferedReader(new FileReader("Archivo"));
				
				String linea =in.readLine();
				
				
				while(linea!=null) {
					
					String [] lectura= linea.split(",");
					
					for (int i=0; i< lectura.length;i++) {
						if (i==0) profHistoricoZona.put(lectura[i], new HashMap<Integer, LinkedHashSet<String>>());
						
						if (i%2 !=0) {
							
							HashMap<Integer, LinkedHashSet<String>> aux = prov.get(lectura[0]);
							
							if(!profHistoricoZona.get(lectura[0]).containsKey(lectura[i])) profHistoricoZona.get(lectura[0]).put(Integer.parseInt(lectura[i]), new LinkedHashSet<String>());
													
						} else if (i%2 ==0) {
				
							HashMap<Integer, LinkedHashSet<String>> aux = prov.get(lectura[0]);
							
							profHistoricoZona.get(lectura[0]).get(Integer.parseInt(lectura[i-1])).add(lectura[i]);
					
						}
					}
				}
				
				
			} catch(IOException e) {System.out.println(e.getMessage());}
		
		}
	
	
	public void creaMapaDiaProf(LinkedHashSet<String> profDia1, LinkedHashSet<String> profDia2, LinkedHashSet<String> profDia3, LinkedHashSet<String> profDia4, LinkedHashSet<String> profDia5){
		
		Map<Integer, LinkedHashSet<String>> mapaDiaProfW = new HashMap<Integer, LinkedHashSet<String>>();
		
		mapaDiaProfW.put(1, profDia1);
		mapaDiaProfW.put(2, profDia2);
		mapaDiaProfW.put(3, profDia3);
		mapaDiaProfW.put(4, profDia4);
		mapaDiaProfW.put(5, profDia5);
	}
	
	public void cargarFichero() {
		
		try {
			
			int numProfDia1=0;
			int numProfDia2=0;
			int numProfDia3=0;
			int numProfDia4=0;
			int numProfDia5=0;
			LinkedHashSet<String> profDia1 = new LinkedHashSet<String>();
			LinkedHashSet<String> profDia2 = new LinkedHashSet<String>();
			LinkedHashSet<String> profDia3 = new LinkedHashSet<String>();
			LinkedHashSet<String> profDia4 = new LinkedHashSet<String>();
			LinkedHashSet<String> profDia5 = new LinkedHashSet<String>();
			
			
			
			BufferedReader in = new BufferedReader(new FileReader("Archivo"));
			
			String linea =in.readLine();
			
			
			while(linea!=null) {
				
				String [] lectura= linea.split(",");
				
				switch(lectura[2]){
				
				case "1":
					profDia1.add(lectura[0]);
					numProfDia1++;break;
				case "2":
					profDia2.add(lectura[0]);
					numProfDia2++;break;
				case "3":
					profDia3.add(lectura[0]);
					numProfDia3++;break;
				case "4":
					profDia4.add(lectura[0]);
					numProfDia4++;break;
				case "5":
					profDia5.add(lectura[0]);
					numProfDia5++;break;
					}
				}
			creaMapaDiaProf(profDia1,profDia2,profDia3,profDia4,profDia5);
			
		} catch(IOException e) {System.out.println(e.getMessage());}
		
	
}

	/*public boolean addGuardia(String idProfesor, Zona zona) {
		if (!guardiasProfesorZonasFecha.containsKey(idProfesor)) {
			guardiasProfesorZonasFecha.put(idProfesor, profesor.registroFechasZona.put(zona.idZona,l) )
		}
	}*/
}
