package practicaequipos;

import java.util.HashMap;
import java.util.LinkedHashSet;

public class Profesor {
	 String idProfesor;
	 String nombre;
	 String apellido1;
	 String apellido2;
	 String email;
	
	 HashMap<Integer, LinkedHashSet<String>> registroFechasZona;
}
